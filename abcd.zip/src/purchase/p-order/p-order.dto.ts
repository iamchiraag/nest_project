import { ObjectId } from "bson";

export class porderDto {
   order_no:number;
   order_id:string;
   order_date?:string;
}