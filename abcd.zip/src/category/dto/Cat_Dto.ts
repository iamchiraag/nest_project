export class CreateCategoryDTO {
    title: string;
    description: string;
  }