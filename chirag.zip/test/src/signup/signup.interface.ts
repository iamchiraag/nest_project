import { Document } from 'mongoose';


export interface sign_in extends Document{

    // email:string;
    // psw:string;
    // gender:string;
    img:string;
} 