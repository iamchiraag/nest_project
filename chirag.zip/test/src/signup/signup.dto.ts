import { ObjectId } from "bson";

export class signupDto {

    // email:string;
    // psw:any;
    // gender:any;
    img:string;
} 
  