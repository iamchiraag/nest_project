import { IsNotEmpty, isNotEmpty } from 'class-validator';

export class CreateCategoryDTO {

    _id?:String;
    // @IsNotEmpty()
    title: string;

    // @IsNotEmpty()
    description: string;
  }