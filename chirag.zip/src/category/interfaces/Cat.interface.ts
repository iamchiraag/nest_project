import { Document } from 'mongoose';
export interface cat_in extends Document {
  _id?:String
  title: String,
  description: String
}