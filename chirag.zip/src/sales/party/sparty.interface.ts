import { Document } from 'mongoose';

export interface Schitthi extends Document {
    Party_Sname:string;
    Party_Snumber:number;
    opening_Saccount:number;
    
}
