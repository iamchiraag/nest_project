import { ObjectId } from "bson";

export class partyDto {
   Party_Sname:string;
   Party_Snumber:number;
   opening_Saccount:number;
}