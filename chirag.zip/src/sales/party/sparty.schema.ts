import * as mongoose from 'mongoose';
export const Party_Schema = new mongoose.Schema({
    Party_Sname:String,
    Party_Snumber:Number,
    opening_Saccount:Number,
})
