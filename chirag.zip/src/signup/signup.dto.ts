import { ObjectId } from "bson";

export class signupDto {
    // _id?:string;
    // email:string;
    email:string;
    password:string;
    // img:string;
} 
  