import { ObjectId } from "bson";

export class partyDto {
   Party_name:string;
   Party_number:number;
   opening_account:number;
   prodID:ObjectId;
}