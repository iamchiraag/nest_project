export default {
  mongoURI: 'mongodb+srv://user:chirag123@cluster0.jefqo.mongodb.net/Stockandinventory?retryWrites=true&w=majority',
};
