import { Document } from 'mongoose';

export interface chitthi extends Document {
    Party_name:string;
    Party_number:number;
    opening_account:number;
}
